#!/bin/sh
# fftw3-android/build.sh
# Compiles fftw3 for Android
# Make sure you have NDK_HOME defined in .bashrc or .bash_profile

INSTALL_DIR="`pwd`/"
SRC_DIR="`pwd`/../fftw-3.3.4"

cd $SRC_DIR

export PATH="$NDK_HOME/toolchains/arm-linux-androideabi-4.9/prebuilt/darwin-x86_64/bin/:$PATH"
export SYS_ROOT="$NDK_HOME/platforms/android-3/arch-arm/"
export CC="arm-linux-androideabi-gcc --sysroot=$SYS_ROOT"
export LD="arm-linux-androideabi-ld"
export AR="arm-linux-androideabi-ar"
export RANLIB="arm-linux-androideabi-ranlib"
export STRIP="arm-linux-androideabi-strip"

EXTRA_CFLAGS_HARD="-mfloat-abi=hard  -D_NDK_MATH_NO_SOFTFP=1 -mfpu=vfpv3-d16"
EXTRA_LDFLAGS_HARD="-Wl,--no-warn-mismatch -Wl,--fix-cortex-a8"

export CFLAGS="-O3 -fomit-frame-pointer -fstrict-aliasing -fno-schedule-insns -ffast-math -march=armv7-a -mhard-float $EXTRA_CFLAGS_HARD"
export LDFLAGS="-Wl,--no-warn-mismatch"

#	--build=x86_64-apple-darwin14.0.0 \

mkdir -p $INSTALL_DIR
./configure \
	--host=arm-linux-androideabi \
	--prefix=$INSTALL_DIR \
	LIBS="-lm_hard -lc -lgcc -lcrystax -L$NDK_HOME/sources/crystax/libs/armeabi-v7a-hard" \
	--disable-fortran \
	--disable-shared \
	--enable-static \
	--enable-threads \
	--with-combined-threads \
	--enable-single 

make
make install
make distclean 

./configure \
	--host=arm-linux-androideabi \
	--prefix=$INSTALL_DIR \
	LIBS="-lm_hard -lc -lgcc -lcrystax -L$NDK_HOME/sources/crystax/libs/armeabi-v7a-hard" \
	--disable-fortran \
	--disable-shared \
	--enable-static \
	--enable-threads \
	--with-combined-threads

make
make install

exit 0