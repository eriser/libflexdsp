#!/bin/sh
# fftw3-android/build.sh
# Compiles fftw3 for Android
# Make sure you have NDK_HOME defined in .bashrc or .bash_profile

INSTALL_DIR="`pwd`/"
SRC_DIR="`pwd`/../fftw-3.3.4"

cd $SRC_DIR

if [ "$OS" == "Windows_NT" ]; then
  PREBUILT="windows-x86_64"
else
  PREBUILT="darwin-x86_64"
fi

if [ "$TARGET_ARCH_ABI" == "" ]; then
  TARGET_ARCH_ABI="armeabi-v7a-hard"
fi

export PATH="$NDK_HOME/toolchains/arm-linux-androideabi-4.9/prebuilt/$PREBUILT/bin/:$PATH"
export SYS_ROOT="$NDK_HOME/platforms/android-3/arch-arm/"
export CC="arm-linux-androideabi-gcc --sysroot=$SYS_ROOT"
export LD="arm-linux-androideabi-ld"
export AR="arm-linux-androideabi-ar"
export RANLIB="arm-linux-androideabi-ranlib"
export STRIP="arm-linux-androideabi-strip"

if [ "$TARGET_ARCH_ABI" == "armeabi-v7a-hard" ]; then
  EXTRA_CFLAGS="-mfloat-abi=hard  -D_NDK_MATH_NO_SOFTFP=1 -mfpu=vfpv3-d16 -march=armv7-a -mhard-float"
  EXTRA_LDFLAGS="-Wl,--no-warn-mismatch -Wl,--fix-cortex-a8"
  EXTRA_LIBS="-lm_hard"
elif [ "$TARGET_ARCH_ABI" == "armeabi-v7a" ]; then
  EXTRA_CFLAGS="-mfloat-abi=softfp -mfpu=vfpv3-d16 -march=armv7-a"
  EXTRA_LDFLAGS="-Wl,--fix-cortex-a8"
  EXTRA_LIBS="-lm"
else 
  EXTRA_CFLAGS="-march=armv5te -mtune=xscale -msoft-float"
  EXTRA_LDFLAGS=""
  EXTRA_LIBS="-lm"
fi

export CFLAGS="-O3 -fomit-frame-pointer -fstrict-aliasing -fno-schedule-insns -ffast-math $EXTRA_CFLAGS"
export LDFLAGS="$EXTRA_LDFLAGS"

mkdir -p $INSTALL_DIR
./configure \
	--host=arm-linux-androideabi \
	--prefix=$INSTALL_DIR \
	LIBS="$EXTRA_LIBS -lc -lgcc -lcrystax -L$NDK_HOME/sources/crystax/libs/$TARGET_ARCH_ABI" \
	--disable-fortran \
	--disable-shared \
	--enable-static \
	--enable-threads \
	--with-combined-threads \
	--enable-single \
	--libdir=$INSTALL_DIR/$TARGET_ARCH_ABI/lib

make
make install
make distclean 

./configure \
	--host=arm-linux-androideabi \
	--prefix=$INSTALL_DIR \
	LIBS="$EXTRA_LIBS -lc -lgcc -lcrystax -L$NDK_HOME/sources/crystax/libs/$TARGET_ARCH_ABI" \
	--disable-fortran \
	--disable-shared \
	--enable-static \
	--enable-threads \
	--with-combined-threads \
	--libdir=$INSTALL_DIR/$TARGET_ARCH_ABI/lib

make
make install

exit 0